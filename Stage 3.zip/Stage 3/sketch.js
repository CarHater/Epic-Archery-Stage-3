const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Constraint = Matter.Constraint;

var engine,world,canvas;
var playerBase,computerBase;
var computerPlayer,player;
var computerArcher,playerArcher;
var arrow;
var angle;
var playerArrows = [];



function setup() {
  
  canvas = createCanvas(1500, 900);
  
   //Initialising Engine
  engine = Engine.create();
  world = engine.world;
	
   //Create Player Base and Computer Base Object
  playerBase = new PlayerBase(200,450,180,150);
  computerBase = new ComputerBase(1000,0,180,150);
  
  computerArcher = new ComputerArcher(width-340,computerBase.body.position.y-180,120,120);
  player = new Player(-1000,-140,50,180);
  computerPlayer = new ComputerPlayer(1000,0,50,180);
  playerArcher = new PlayerArcher(-955,-160,120,120);
  computerArcher = new ComputerArcher(-50,-160,120,120);
  angle=-PI/4;  

 }

function draw() {

  background(180);

  Engine.update(engine);

  // Title
  fill("#FFFF");
  textAlign("center");
  textSize(40);
  text("EPIC ARCHERY", width / 2, 100);

   //Display Playerbase and computer base 
  playerBase.display();
  computerBase.display();

  computerArcher.display();
  playerArcher.display();

   //display Player and computerplayer
  player.display();
  computerPlayer.display();


  for (var i = 0; i < playerArrows.length; i++) {
    showArrows(i, playerArrows);
  }
}

function keyPressed() {

  if(keyCode === 32){
    var posX = playerArcher.body.position.x;
    var posY = playerArcher.body.position.y;
    var angle = playerArcher.body.angle+PI/2;

    var arrow = new PlayerArrow(posX+15,posY+140,100,10);

    arrow.trajectory = [];
    Matter.Body.setAngle(arrow.body, angle);
    playerArrows.push(arrow);

  }
}

function keyReleased () {

  if(keyCode === 32){
    if (playerArrows.length) {
      var angle = playerArcher.body.angle+PI/2;
      playerArrows[playerArrows.length - 1].shoot(angle);
    }
  }

}

function showArrows(index, arrows) {
  arrows[index].display();

}
